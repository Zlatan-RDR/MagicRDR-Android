using System.Buffers.Binary;
using System.Text;

namespace MagicRDR.Core.Formats;

/// <summary>
/// Unpacks a packed resource file (<c>RSC05/06/85/86</c> header + compressed body) into its raw data.
/// Only the Switch layout (header, then one or more Zstandard frames) is supported. Xbox 360 resources use LZX through a
/// Windows-only native library, and PS3 resources are not verified, so both report <see cref="NotSupportedException"/>.
/// <para>
/// The body is read frame by frame: the exact length of each frame is measured first, so padding after the last frame
/// (which made a plain stream decoder fail with "Premature end of stream") is ignored, and a really truncated frame is
/// reported with the exact position instead of a generic error.
/// </para>
/// </summary>
public static class RpfResourceUnpacker
{
    public static async Task<byte[]> UnpackAsync(byte[] resource, RpfPlatform platform, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(resource);

        if (platform != RpfPlatform.Switch)
        {
            throw new NotSupportedException($"Unpacking {platform} resources is not supported yet (only Switch / Zstandard).");
        }

        using var input = new MemoryStream(resource, writable: false);
        RpfResourceInfo info = RpfResourceInfo.Read(input, platform);
        if (!info.IsResource)
        {
            throw new InvalidDataException("This file is not a packed resource (no RSC header).");
        }

        bool extended = info.Version is "RSC85" or "RSC86";
        int headerLength = extended ? 16 : 12;
        if (resource.Length <= headerLength)
        {
            throw new InvalidDataException("The resource has no data after its header.");
        }

        if (extended && info.ResourceType == 2)
        {
            throw new NotSupportedException("This resource is encrypted; decrypting resources is not supported yet.");
        }

        using var output = new MemoryStream();
        int position = headerLength;
        int frames = 0;

        while (resource.Length - position >= 4 && ZstdFrames.IsFrameStart(resource.AsSpan(position)))
        {
            cancellationToken.ThrowIfCancellationRequested();

            if (!ZstdFrames.TryReadFrame(resource.AsSpan(position), out ZstdFrame frame, out string? error))
            {
                throw new InvalidDataException($"The Zstandard frame at byte {position} is damaged or cut off: {error}.");
            }

            if (!frame.IsSkippable)
            {
                using var slice = new MemoryStream(resource, position, frame.Length, writable: false);
                await RpfCompression.ZstdDecompressAsync(slice, output, null, cancellationToken).ConfigureAwait(false);
                frames++;
            }

            position += frame.Length;
        }

        if (frames == 0)
        {
            throw new InvalidDataException($"No Zstandard frame was found after the {headerLength}-byte resource header.");
        }

        return output.ToArray();
    }

    /// <summary>
    /// One-line technical summary of a packed resource (header fields, body size, Zstandard frames, trailing bytes),
    /// meant for the viewer's notice line so problems can be diagnosed from a screenshot. Never throws.
    /// </summary>
    public static string Describe(byte[] resource, RpfPlatform platform)
    {
        try
        {
            using var input = new MemoryStream(resource, writable: false);
            RpfResourceInfo info = RpfResourceInfo.Read(input, platform);
            if (!info.IsResource)
            {
                return string.Empty;
            }

            bool extended = info.Version is "RSC85" or "RSC86";
            int headerLength = extended ? 16 : 12;
            var text = new StringBuilder();
            text.Append(info.Version).Append(" type ").Append(info.ResourceType)
                .Append(" flags 0x").Append(((uint)info.Flag1).ToString("X8"));
            if (extended)
            {
                text.Append('/').Append(((uint)info.Flag2).ToString("X8"));
            }

            text.Append(" body ").Append(Math.Max(0, resource.Length - headerLength)).Append(" B");

            int position = headerLength;
            int count = 0;
            while (resource.Length - position >= 4 && ZstdFrames.IsFrameStart(resource.AsSpan(position)))
            {
                if (!ZstdFrames.TryReadFrame(resource.AsSpan(position), out ZstdFrame frame, out string? error))
                {
                    text.Append("; frame ").Append(count + 1).Append(" at ").Append(position).Append(" is cut off (").Append(error).Append(')');
                    return text.ToString();
                }

                count++;
                text.Append("; frame ").Append(count).Append(": ").Append(frame.Length).Append(" B");
                if (frame.ContentSize is { } size)
                {
                    text.Append(" -> ").Append(size).Append(" B");
                }

                position += frame.Length;
            }

            int trailing = resource.Length - position;
            if (count == 0)
            {
                text.Append("; no Zstandard frame at byte ").Append(headerLength);
            }
            else if (trailing > 0)
            {
                text.Append("; ").Append(trailing).Append(" trailing byte(s)");
            }

            return text.ToString();
        }
        catch (Exception)
        {
            return string.Empty;
        }
    }
}
