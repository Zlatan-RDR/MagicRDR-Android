using MagicRDR.App.ViewModels;
using Microsoft.Extensions.DependencyInjection;

namespace MagicRDR.App;

public partial class App : Application
{
    private readonly IServiceProvider _services;

    // IMPORTANT: do not take MainPage (or anything that loads XAML) as a constructor parameter.
    // The DI container would build that page BEFORE this constructor runs, i.e. before App.xaml
    // has been loaded, so every {StaticResource ...} in the page fails with XamlParseException.
    public App(IServiceProvider services)
    {
        InitializeComponent();
        _services = services;
        UserAppTheme = AppTheme.Dark; // the palette is dark-only
    }

    protected override Window CreateWindow(IActivationState? activationState)
    {
        // App.xaml (colours, styles) is fully loaded by now, so the page can be created safely.
        var window = new Window(_services.GetRequiredService<MainPage>());
        window.Destroying += (_, _) => _services.GetRequiredService<MainViewModel>().Shutdown();
        return window;
    }
}
