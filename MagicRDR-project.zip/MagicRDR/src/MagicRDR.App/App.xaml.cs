using MagicRDR.App.ViewModels;

namespace MagicRDR.App;

public partial class App : Application
{
    private readonly MainPage _mainPage;
    private readonly MainViewModel _viewModel;

    public App(MainPage mainPage, MainViewModel viewModel)
    {
        InitializeComponent();
        _mainPage = mainPage;
        _viewModel = viewModel;
        UserAppTheme = AppTheme.Dark; // the palette below is dark-only
    }

    protected override Window CreateWindow(IActivationState? activationState)
    {
        var window = new Window(_mainPage);
        window.Destroying += (_, _) => _viewModel.Shutdown();
        return window;
    }
}
