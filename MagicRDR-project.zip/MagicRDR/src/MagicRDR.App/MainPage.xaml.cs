using MagicRDR.App.ViewModels;

namespace MagicRDR.App;

public partial class MainPage : ContentPage
{
    private readonly MainViewModel _viewModel;

    public MainPage(MainViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = _viewModel = viewModel;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _viewModel.InitializeAsync();
    }

    /// <summary>The Android back button walks up the archive's folders before it leaves the app.</summary>
    protected override bool OnBackButtonPressed()
    {
        if (_viewModel.CanGoUp)
        {
            _viewModel.GoUpCommand.Execute(null);
            return true;
        }

        return base.OnBackButtonPressed();
    }
}
