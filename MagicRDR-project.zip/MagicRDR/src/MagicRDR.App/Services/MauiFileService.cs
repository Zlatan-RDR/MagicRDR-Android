using CommunityToolkit.Maui.Storage;

namespace MagicRDR.App.Services;

public sealed class MauiFileService : IFileService
{
    private const int CopyBufferSize = 1 << 20;

    public MauiFileService()
    {
        WorkDirectory = Path.Combine(FileSystem.AppDataDirectory, "work");
        Directory.CreateDirectory(WorkDirectory);
    }

    public string WorkDirectory { get; }

    public string DataDirectory => FileSystem.AppDataDirectory;

    public void CleanWorkDirectory()
    {
        try
        {
            foreach (string file in Directory.EnumerateFiles(WorkDirectory))
            {
                TryDelete(file);
            }

            foreach (string dir in Directory.EnumerateDirectories(WorkDirectory))
            {
                try
                {
                    Directory.Delete(dir, recursive: true);
                }
                catch (IOException)
                {
                }
            }
        }
        catch (IOException)
        {
        }
    }

    public async Task<PickedFile?> PickAsync(string title)
    {
        FileResult? result = await FilePicker.Default.PickAsync(new PickOptions { PickerTitle = title });
        return result == null ? null : new PickedFile(result.FileName, result.OpenReadAsync);
    }

    public async Task<string> CopyToWorkFolderAsync(
        PickedFile file,
        string extension,
        IProgress<double>? progress,
        CancellationToken cancellationToken)
    {
        Directory.CreateDirectory(WorkDirectory);
        string target = Path.Combine(WorkDirectory, Guid.NewGuid().ToString("N") + extension);

        try
        {
            await using Stream input = await file.OpenReadAsync();
            long length = 0;
            try
            {
                length = input.CanSeek ? input.Length : 0;
            }
            catch (NotSupportedException)
            {
            }

            await using var output = new FileStream(target, FileMode.CreateNew, FileAccess.Write, FileShare.None, CopyBufferSize, FileOptions.Asynchronous);
            byte[] buffer = new byte[CopyBufferSize];
            long total = 0;
            int read;
            while ((read = await input.ReadAsync(buffer.AsMemory(), cancellationToken)) > 0)
            {
                await output.WriteAsync(buffer.AsMemory(0, read), cancellationToken);
                total += read;
                if (length > 0)
                {
                    progress?.Report((double)total / length);
                }
            }

            return target;
        }
        catch
        {
            TryDelete(target);
            throw;
        }
    }

    public async Task<ExportResult> SaveAsync(string suggestedName, Stream content, CancellationToken cancellationToken)
    {
        FileSaverResult result = await FileSaver.Default.SaveAsync(suggestedName, content, cancellationToken);
        return result.IsSuccessful
            ? new ExportResult(true)
            : new ExportResult(false, result.Exception?.Message);
    }

    public async Task<Stream?> OpenPackageFileAsync(string name)
    {
        try
        {
            return await FileSystem.OpenAppPackageFileAsync(name);
        }
        catch (Exception)
        {
            return null;
        }
    }

    private static void TryDelete(string path)
    {
        try
        {
            File.Delete(path);
        }
        catch (IOException)
        {
        }
    }
}
