# Magic RDR (Android, .NET 10 MAUI)

Android-only port of Magic-RDR: browse, extract, replace (translation injection) and save Red Dead Redemption `.RPF` archives.

```
src/MagicRDR.Core         net10.0 library: RPF6 parsing, TOC rebuild, deflate/zstd, AES TOC crypto, names (no UI)
src/MagicRDR.App          net10.0-android MAUI app (MVVM): minimum Android 10 (API 29), target Android 16 (API 36)
tests/MagicRDR.Core.Tests xUnit tests on synthetic data (run in CI)
docs/                     ARCHITECTURE, FEATURE-PARITY, DEVELOPMENT, RELEASING (Arabic)
```

Read first: `docs/UPDATING.md` (how to update), `docs/RELEASING.md` (permanent signing key and in-place updates) and `docs/ARCHITECTURE.md` (rules for new features).

* Names: RPF6 stores hashes only. Put a `names.txt` in the repository root (bundled at build time) or use **Import names** in the app.
* Keep a backup of any `.rpf` before saving over it.
