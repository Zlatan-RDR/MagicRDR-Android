# Magic RDR (Android, .NET 10 MAUI)

Android-only port of Magic-RDR: browse, extract, replace (translation injection) and save Red Dead Redemption `.RPF` archives.

```
src/MagicRDR.Core         net10.0 library: RPF6 parsing, TOC rebuild, deflate/zstd, AES TOC crypto (no UI)
src/MagicRDR.App          net10.0-android MAUI app (MVVM): minimum Android 10 (API 29), target Android 16 (API 36)
tests/MagicRDR.Core.Tests xUnit round-trip tests on a synthetic RPF
```

* Names: RPF6 stores hashes only. Put a `names.txt` (one name per line) in `src/MagicRDR.App/Resources/Raw/`
  or use the **Names** button in the app; otherwise entries show as `0xXXXXXXXX`.
* Every build is signed with a fresh debug key, so uninstall the previous build before installing a new one.
* Keep a backup of any `.rpf` before saving over it.
