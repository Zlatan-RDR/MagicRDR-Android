namespace MagicRDR.Core.Formats;

/// <summary>
/// Unpacks a packed resource file (<c>RSC05/06/85/86</c> header + compressed body) into its raw data.
/// Only the Switch layout (header, then one Zstandard frame) is supported. Xbox 360 resources use LZX through a
/// Windows-only native library, and PS3 resources are not verified, so both report <see cref="NotSupportedException"/>.
/// </summary>
public static class RpfResourceUnpacker
{
    public static async Task<byte[]> UnpackAsync(byte[] resource, RpfPlatform platform, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(resource);

        if (platform != RpfPlatform.Switch)
        {
            throw new NotSupportedException($"Unpacking {platform} resources is not supported yet (only Switch / Zstandard).");
        }

        using var input = new MemoryStream(resource, writable: false);
        RpfResourceInfo info = RpfResourceInfo.Read(input, platform);
        if (!info.IsResource)
        {
            throw new InvalidDataException("This file is not a packed resource (no RSC header).");
        }

        bool extended = info.Version is "RSC85" or "RSC86";
        int headerLength = extended ? 16 : 12;
        if (resource.Length <= headerLength)
        {
            throw new InvalidDataException("The resource has no data after its header.");
        }

        if (extended && info.ResourceType == 2)
        {
            throw new NotSupportedException("This resource is encrypted; decrypting resources is not supported yet.");
        }

        using var compressed = new MemoryStream(resource, headerLength, resource.Length - headerLength, writable: false);
        using var output = new MemoryStream();
        await RpfCompression.ZstdDecompressAsync(compressed, output, null, cancellationToken).ConfigureAwait(false);
        return output.ToArray();
    }
}
